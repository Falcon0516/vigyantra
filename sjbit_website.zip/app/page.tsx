import HeroScrub from '@/components/hero/HeroScrub';
import EventsSection from '@/components/events/EventsSection';
import Footer from '@/components/layout/Footer';
import ScrollProgressIndicator from '@/components/layout/ScrollProgressIndicator';

export default function Home() {
  return (
    <main className="flex min-h-screen flex-col bg-[var(--color-hero-bg)]">
      <ScrollProgressIndicator />
      <HeroScrub />
      <EventsSection />
      <Footer />
    </main>
  );
}
