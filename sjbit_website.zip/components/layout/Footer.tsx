import React from 'react';
import { content } from '@/lib/content';
import { ArrowRight } from 'lucide-react';

export default function Footer() {
  const { site } = content;

  return (
    <footer className="bg-[#0B0B0C] text-white py-20 px-6 border-t border-white/10">
      <div className="max-w-6xl mx-auto flex flex-col items-center text-center">
        
        <h2 className="font-serif text-3xl md:text-5xl mb-4 text-[#F7F1E6]">
          {site.tagline}
        </h2>
        
        <p className="text-gray-400 mb-10 max-w-lg text-lg">
          {site.prizePoolLabel} <span className="text-white font-semibold">{site.prizePoolDisplay}</span>
        </p>

        <a
          href={site.registerCtaUrl}
          target="_blank"
          rel="noopener noreferrer"
          className="group inline-flex items-center justify-center px-8 py-4 bg-white text-black font-medium rounded-full transition-transform active:scale-95 hover:bg-gray-100 mb-16"
        >
          {site.registerCtaLabel}
          <ArrowRight className="w-4 h-4 ml-2 transition-transform group-hover:translate-x-1" />
        </a>

        <div className="flex gap-6 mb-8 text-gray-400 font-medium">
          {/* TODO: add real social links */}
          <a href="#" className="hover:text-white transition-colors" aria-label="Instagram">
            Instagram
          </a>
          <a href="#" className="hover:text-white transition-colors" aria-label="LinkedIn">
            LinkedIn
          </a>
          <a href="#" className="hover:text-white transition-colors" aria-label="X (Twitter)">
            X (Twitter)
          </a>
        </div>

        <div className="text-sm text-gray-600">
          © {new Date().getFullYear()} {site.campusName}. All rights reserved.
        </div>
      </div>
    </footer>
  );
}
