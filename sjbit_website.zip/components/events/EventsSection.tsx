import React from 'react';
import { content } from '@/lib/content';
import EventCard from './EventCard';

export default function EventsSection() {
  const { site, events } = content;

  return (
    <section className="py-32 px-6 bg-[var(--color-background)] relative z-10" id="events">
      <div className="max-w-6xl mx-auto">
        
        <header className="text-center mb-24 max-w-3xl mx-auto">
          <div className="flex items-center justify-center gap-4 mb-6">
            {site.pillars.map((pillar, idx) => (
              <React.Fragment key={pillar}>
                <span className="text-sm font-semibold tracking-[0.2em] text-gray-500">
                  {pillar}
                </span>
                {idx < site.pillars.length - 1 && (
                  <span className="text-gray-300">·</span>
                )}
              </React.Fragment>
            ))}
          </div>
          <h2 className="font-serif text-4xl md:text-5xl lg:text-6xl text-[var(--color-foreground)] leading-tight drop-shadow-sm">
            {site.subTagline}
          </h2>
        </header>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 lg:gap-12">
          {events.map((event, index) => (
            <EventCard key={event.id} event={event} index={index} />
          ))}
        </div>
        
      </div>
    </section>
  );
}
