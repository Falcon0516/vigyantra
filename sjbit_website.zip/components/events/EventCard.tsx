'use client';

import React from 'react';
import { motion } from 'framer-motion';
import * as LucideIcons from 'lucide-react';
import { EventItem, getEventTheme } from '@/lib/content';

interface EventCardProps {
  event: EventItem;
  index: number;
}

export default function EventCard({ event, index }: EventCardProps) {
  // Dynamically resolve the icon from lucide-react
  // @ts-expect-error - indexing lucide icons dynamically
  const IconComponent = LucideIcons[event.icon] || LucideIcons.HelpCircle;

  return (
    <motion.div
      initial={{ opacity: 0, y: 30 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "-100px" }}
      transition={{ duration: 0.6, delay: index * 0.08, ease: "easeOut" }}
      style={getEventTheme(event)}
      className="group relative flex flex-col bg-white/70 backdrop-blur-sm rounded-2xl p-8 shadow-sm transition-all duration-300 hover:-translate-y-1 hover:shadow-md border border-transparent hover:border-[var(--accent)] h-full"
    >
      <div className="flex items-start justify-between mb-6">
        <div className="flex items-center justify-center w-14 h-14 rounded-2xl bg-[var(--accent-bg)]">
          <IconComponent className="w-7 h-7 text-[var(--accent)]" strokeWidth={1.5} />
        </div>
        <span className="font-sans text-3xl font-light text-[var(--accent)] tabular-nums tracking-tighter">
          {event.id}
        </span>
      </div>

      <h3 className="font-serif text-2xl font-bold mb-3 text-[var(--color-foreground)]">
        {event.title}
      </h3>
      
      <p className="font-sans text-gray-600 mb-8 leading-relaxed flex-grow">
        {event.description}
      </p>

      <div className="flex flex-wrap gap-2 mb-8">
        {event.tags.map((tag) => (
          <span
            key={tag}
            className="px-3 py-1 text-xs font-semibold tracking-widest uppercase rounded-full bg-[var(--accent-bg)] text-[var(--accent)]"
          >
            {tag}
          </span>
        ))}
      </div>

      <a
        href={event.exploreUrl}
        target="_blank"
        rel="noopener noreferrer"
        className="mt-auto inline-flex items-center justify-center w-full py-4 rounded-xl bg-[var(--accent)] text-white font-medium transition-transform active:scale-[0.98] group-hover:shadow-sm"
      >
        Explore Now
        <LucideIcons.ArrowRight className="w-4 h-4 ml-2 transition-transform group-hover:translate-x-1" />
      </a>
    </motion.div>
  );
}
