'use client';

import React, { useEffect, useRef, useState } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import HeroOverlay from './HeroOverlay';
import Image from 'next/image';
import { ChevronDown } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

export default function HeroScrub() {
  const containerRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const videoRef = useRef<HTMLVideoElement>(null);
  
  const [isVideoLoaded, setIsVideoLoaded] = useState(false);
  const [prefersReducedMotion, setPrefersReducedMotion] = useState(false);
  const [scrollProgress, setScrollProgress] = useState(0);

  useEffect(() => {
    const mediaQuery = window.matchMedia('(prefers-reduced-motion: reduce)');
    setPrefersReducedMotion(mediaQuery.matches);

    const handleChange = (e: MediaQueryListEvent) => setPrefersReducedMotion(e.matches);
    mediaQuery.addEventListener('change', handleChange);
    return () => mediaQuery.removeEventListener('change', handleChange);
  }, []);

  useEffect(() => {
    if (prefersReducedMotion) return;

    const container = containerRef.current;
    const canvas = canvasRef.current;
    const video = videoRef.current;

    if (!container || !canvas || !video) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const isMobile = window.innerWidth < 768;
    const runwayHeight = isMobile ? '250vh' : '400vh';
    container.style.height = runwayHeight;

    let isSeeking = false;
    let pendingProgress: number | null = null;
    let tickCounter = 0;

    const drawFrame = () => {
      const { videoWidth, videoHeight } = video;
      const { width, height } = canvas;

      if (videoWidth === 0 || videoHeight === 0) return;

      const scale = Math.max(width / videoWidth, height / videoHeight);
      const drawWidth = videoWidth * scale;
      const drawHeight = videoHeight * scale;
      const drawX = (width - drawWidth) / 2;
      const drawY = (height - drawHeight) / 2;

      ctx.clearRect(0, 0, width, height);
      ctx.drawImage(video, drawX, drawY, drawWidth, drawHeight);
    };

    const handleSeeked = () => {
      isSeeking = false;
      drawFrame();
      
      if (pendingProgress !== null) {
        const nextProgress = pendingProgress;
        pendingProgress = null;
        triggerSeek(nextProgress);
      }
    };

    const triggerSeek = (progress: number) => {
      if (isSeeking) {
        pendingProgress = progress;
        return;
      }
      
      if (!Number.isFinite(video.duration) || video.duration === 0) return;

      isSeeking = true;
      video.currentTime = progress * video.duration;
    };

    video.addEventListener('seeked', handleSeeked);
    video.addEventListener('loadeddata', () => {
      setIsVideoLoaded(true);
      // Draw initial frame
      resizeCanvas();
    });

    const resizeCanvas = () => {
      const dpr = isMobile ? Math.min(window.devicePixelRatio, 2) : window.devicePixelRatio || 1;
      const rect = container.getBoundingClientRect();
      
      canvas.width = rect.width * dpr;
      canvas.height = window.innerHeight * dpr;
      
      ctx.scale(dpr, dpr);
      canvas.style.width = `${rect.width}px`;
      canvas.style.height = `${window.innerHeight}px`;

      if (video.readyState >= 2) {
        drawFrame();
      }
    };

    window.addEventListener('resize', resizeCanvas);
    resizeCanvas();

    const trigger = ScrollTrigger.create({
      trigger: container,
      start: 'top top',
      end: 'bottom bottom',
      pin: canvas,
      scrub: true,
      onUpdate: (self) => {
        setScrollProgress(self.progress);
        
        if (isMobile) {
          tickCounter++;
          if (tickCounter % 2 !== 0) return; // Throttle on mobile
        }
        
        if (isVideoLoaded) {
           triggerSeek(self.progress);
        }
      },
    });

    return () => {
      window.removeEventListener('resize', resizeCanvas);
      video.removeEventListener('seeked', handleSeeked);
      trigger.kill();
    };
  }, [prefersReducedMotion, isVideoLoaded]);

  if (prefersReducedMotion) {
    return (
      <section className="relative w-full h-screen bg-[var(--color-hero-bg)] overflow-hidden">
        <Image
          src="/images/hero-poster.jpg"
          alt="Campus Hero"
          fill
          className="object-cover"
          priority
        />
        <div className="absolute inset-0 bg-black/40" />
        <HeroOverlay progress={1} prefersReducedMotion={true} />
      </section>
    );
  }

  return (
    <section ref={containerRef} className="relative w-full bg-[var(--color-hero-bg)]">
      <div className="sticky top-0 h-screen w-full overflow-hidden">
        {/* Placeholder image while video buffers */}
        <div
          className={`absolute inset-0 transition-opacity duration-1000 ${
            isVideoLoaded ? 'opacity-0 pointer-events-none' : 'opacity-100'
          }`}
        >
          <Image
            src="/images/hero-poster.jpg"
            alt="Loading Campus Video"
            fill
            className="object-cover blur-sm"
            priority
          />
        </div>

        <video
          ref={videoRef}
          src="/videos/hero-source.mp4"
          muted
          playsInline
          preload="auto"
          className="hidden"
        />
        <canvas ref={canvasRef} className="absolute inset-0 w-full h-full object-cover" />
        
        {/* Overlay dark wash for text readability */}
        <div className="absolute inset-0 bg-black/30" />
        
        <HeroOverlay progress={scrollProgress} />

        {/* Scroll Cue in final 10% */}
        <div 
          className={`absolute bottom-8 left-1/2 -translate-x-1/2 flex flex-col items-center text-white transition-opacity duration-500 ${
            scrollProgress > 0.9 && scrollProgress < 1 ? 'opacity-100' : 'opacity-0 pointer-events-none'
          }`}
        >
          <span className="text-sm tracking-wider mb-2 font-medium">EXPLORE EVENTS</span>
          <ChevronDown className="w-6 h-6 animate-bounce" />
        </div>
      </div>
    </section>
  );
}
