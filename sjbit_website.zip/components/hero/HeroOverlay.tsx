'use client';

import React, { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { content, HeroOverlayFrame } from '@/lib/content';

interface HeroOverlayProps {
  progress: number;
  prefersReducedMotion?: boolean;
}

export default function HeroOverlay({ progress, prefersReducedMotion = false }: HeroOverlayProps) {
  const [activeFrameIndex, setActiveFrameIndex] = useState<number>(-1);
  const { heroOverlayTimeline, site } = content;

  useEffect(() => {
    if (prefersReducedMotion) {
      // Just show the last frame
      setActiveFrameIndex(heroOverlayTimeline.length - 1);
      return;
    }

    // Find which frame we are currently in based on scroll progress
    const index = heroOverlayTimeline.findIndex(
      (frame) => progress >= frame.scrollStart && progress <= frame.scrollEnd
    );
    
    // If we're past the end, show the last frame
    if (index === -1 && progress > heroOverlayTimeline[heroOverlayTimeline.length - 1].scrollEnd) {
      setActiveFrameIndex(heroOverlayTimeline.length - 1);
    } else {
      setActiveFrameIndex(index);
    }
  }, [progress, prefersReducedMotion, heroOverlayTimeline]);

  return (
    <div className="absolute inset-0 flex items-center justify-center pointer-events-none p-6 text-center">
      <AnimatePresence mode="wait">
        {activeFrameIndex !== -1 && (
          <OverlayText 
            key={activeFrameIndex} 
            frame={heroOverlayTimeline[activeFrameIndex]} 
            prefersReducedMotion={prefersReducedMotion}
            prizePoolAmount={site.prizePoolAmount}
          />
        )}
      </AnimatePresence>
    </div>
  );
}

function OverlayText({ 
  frame, 
  prefersReducedMotion,
  prizePoolAmount
}: { 
  frame: HeroOverlayFrame, 
  prefersReducedMotion: boolean,
  prizePoolAmount: number
}) {
  const isPrizePoolFrame = frame.sub.includes("₹");
  const [displayAmount, setDisplayAmount] = useState(prefersReducedMotion ? prizePoolAmount : 0);

  useEffect(() => {
    if (!isPrizePoolFrame || prefersReducedMotion) return;

    let startTime: number;
    const duration = 1200; // 1.2 seconds

    const animateCount = (timestamp: number) => {
      if (!startTime) startTime = timestamp;
      const elapsedTime = timestamp - startTime;
      
      const progress = Math.min(elapsedTime / duration, 1);
      // Ease out cubic
      const easeProgress = 1 - Math.pow(1 - progress, 3);
      
      setDisplayAmount(Math.floor(easeProgress * prizePoolAmount));

      if (progress < 1) {
        requestAnimationFrame(animateCount);
      }
    };

    requestAnimationFrame(animateCount);
  }, [isPrizePoolFrame, prizePoolAmount, prefersReducedMotion]);

  // Highlight the prize pool or specific text
  const renderSub = (text: string) => {
    if (isPrizePoolFrame && text.includes("₹4,00,000")) {
      const parts = text.split("₹4,00,000");
      return (
        <>
          {parts[0]}
          <span className="text-[var(--color-background)] font-bold">
            ₹{displayAmount.toLocaleString('en-IN')}
          </span>
          {parts[1]}
        </>
      );
    }
    return text;
  };

  return (
    <motion.div
      initial={prefersReducedMotion ? { opacity: 1, y: 0 } : { opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={prefersReducedMotion ? { opacity: 0, y: 0 } : { opacity: 0, y: -20 }}
      transition={{ duration: 0.6, ease: "easeOut" }}
      className="max-w-4xl text-white"
    >
      <h1 className="font-serif text-4xl md:text-6xl lg:text-7xl mb-4 tracking-tight drop-shadow-md">
        {frame.heading}
      </h1>
      <p className="text-lg md:text-2xl text-gray-200 tracking-wide font-light drop-shadow-sm">
        {renderSub(frame.sub)}
      </p>
    </motion.div>
  );
}
